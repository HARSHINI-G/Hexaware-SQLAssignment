import requests
from datetime import datetime, timedelta
import json
 
# Base URL of your FastAPI application
BASE_URL = "http://127.0.0.1:8029"
 
def print_response(response):
    """Helper function to print response details"""
    print(f"Status Code: {response.status_code}")
    try:
        print("Response JSON:", json.dumps(response.json(), indent=2))
    except ValueError:
        print("Response Text:", response.text)
    print("-" * 50)
 
def test_all_endpoints():
    # Test data
    test_city = "New York"
    test_date = datetime.now().isoformat()
    test_data = {
        "city": test_city,
        "temperature": 22.5,
        "humidity": 65,
        "wind_speed": 10.2,
        "description": "Partly cloudy"
    }
 
    print("\nTesting Weather Data Management System API\n")
 
    # 1. Create a new record
    print("Creating a new weather record:")
    response = requests.post(f"{BASE_URL}/records/", json=test_data)
    print_response(response)
    record_id = response.json().get("id")
 
    if not record_id:
        print("Failed to create record. Exiting tests.")
        return
 
    # 2. Get all records
    print("Getting all weather records:")
    response = requests.get(f"{BASE_URL}/records/")
    print_response(response)
 
    # 3. Get specific record
    print(f"Getting record with ID {record_id}:")
    response = requests.get(f"{BASE_URL}/records/{record_id}")
    print_response(response)
 
    # 4. Get records by city
    print(f"Getting records for city {test_city}:")
    response = requests.get(f"{BASE_URL}/records/city/{test_city}")
    print_response(response)
 
    # 5. Get records by date
    print(f"Getting records for date {test_date}:")
    response = requests.get(f"{BASE_URL}/records/date/{test_date}")
    print_response(response)
 
    # 6. Update record
    print(f"Updating record {record_id}:")
    update_data = {"temperature": 24.0, "description": "Sunny"}
    response = requests.put(f"{BASE_URL}/records/{record_id}", json=update_data)
    print_response(response)
 
    # 7. Get average temperature
    print(f"Getting average temperature for {test_city}:")
    response = requests.get(f"{BASE_URL}/records/city/{test_city}/average/temperature")
    print_response(response)
 
    # 8. Get average humidity
    print(f"Getting average humidity for {test_city}:")
    response = requests.get(f"{BASE_URL}/records/city/{test_city}/average/humidity")
    print_response(response)
 
    # 9. Delete record (commented out by default to preserve test data)
    # print(f"Deleting record {record_id}:")
    # response = requests.delete(f"{BASE_URL}/records/{record_id}")
    # print_response(response)
 
if __name__ == "__main__":
    test_all_endpoints()
 